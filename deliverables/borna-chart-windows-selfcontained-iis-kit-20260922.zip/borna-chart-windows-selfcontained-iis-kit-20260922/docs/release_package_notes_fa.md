# بسته Windows Self-Contained + IIS Kit

این بسته برای اجرای سریع، یک‌کلیکی، و همچنین استقرار رسمی‌تر روی Windows Server آماده شده است.

## فایل‌هایی که کاربر نهایی باید ببیند
- OPEN_ME_FIRST.bat
- RUN_ON_SERVER_IP.bat
- RESET_AND_RUN_DEMO.bat
- ENABLE_WINDOWS_FIREWALL_8000.bat
- OPEN_IIS_DEPLOY_GUIDE.bat

## شامل چه چیزهایی است؟
- API FastAPI
- Web Console
- فایل‌های BAT برای setup و run
- نمونه Firewall helper
- راهنمای IIS / Reverse Proxy
- تنظیمات workflow/config

## عمداً در این بسته نیامده است
- tests
- prototype
- virtual environment محلی
- artifacts توسعه
